/**
 * 
 */
/**
 * 
 */
module MySql_j {
	requires java.sql;
}