package game_separate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

public class HashUser {

	public static HashMap<String, Object> insertPlayer(Player_Status ps) {
		
		HashMap<String, Object> uMap = new HashMap<>();
		
		String P_hp = Integer.toString(ps.getP_hp());
		String P_str = Integer.toString(ps.getP_str());
		String P_dex = Integer.toString(ps.getP_dex());
		
		uMap.put("p_name", ps.getP_name());
		uMap.put("p_job", ps.getP_job());
		uMap.put("p_weapon", ps.getP_weapon_name());
		uMap.put("p_hp", P_hp);
		uMap.put("p_str", P_str);
		uMap.put("p_dex", P_dex);

		return uMap;
	}
}
