package game_separate;

import java.util.Scanner;

public class Battle_Monster {
    public void Battle(Player_Status ps, Monster_Status ms, int Monster_kind) {
        Scanner sc = new Scanner(System.in);

        System.out.println("선택지를 골라주십시오!! \n(1.Attack!  2.Run!)");
        System.out.println("----------------------------------------------------------");
        int Battle_choice = sc.nextInt();

        if (Battle_choice == 1) {
            System.out.println("--------------전투 돌입--------------");

            int Origin_Player_Hp = ps.getP_hp();
            int Origin_Monster_Hp = ms.getMonster_HP();
            int Player_str = ps.getP_str();
            int Monster_str = ms.getMonster_str();

            while (Origin_Monster_Hp > 0 && Origin_Player_Hp > 0) {
                System.out.println(ps.getP_name() + " 님의 " + ps.getP_weapon_name() +
                        "을(를) 이용한 " + ms.getMonster_name() + " 공격!");

                int Monster_Hp = Origin_Monster_Hp - Player_str;
                System.out.println(Player_str + " 데미지를 주었습니다!");
                System.out.println(ms.getMonster_name() + " 의 남은 체력: " + Monster_Hp);
                System.out.println("--------------------------------------------- ");

                if (Monster_Hp <= 0) {
                    System.out.println("전투승리");
                    Origin_Player_Hp = ps.getP_hp(); // 체력 업데이트
                    System.out.println("현재 " + ps.getP_name() + "님의 남은 체력은 " + Origin_Player_Hp + "입니다.");
                    break;
                }

                System.out.println(ms.getMonster_name() + "의 " + ms.getM_weapon_name() + "을(를) 이용한 공격!");

                Origin_Player_Hp -= Monster_str; // 캐릭터 체력 감소
                System.out.println(Monster_str + " 데미지를 입었습니다!");
                System.out.println(ps.getP_name() + " 님의 남은 체력: " + Origin_Player_Hp);
                System.out.println("--------------------------------------------- ");

                if (Origin_Player_Hp <= 0) {
                    System.out.printf("전투패배 \n캐릭터가 사망하였습니다.");
                    break;
                }

                System.out.println("선택지를 골라주십시오!! \n(1.Attack!  2.Run!)");
                System.out.println("----------------------------------------------------------");
                Battle_choice = sc.nextInt();
                if (Battle_choice != 1) {
                    System.out.println("무사히 도망쳤습니다.");
                    System.out.println("현재 " + ps.getP_name() + "님의 남은 체력은 " + Origin_Player_Hp + "입니다.");
                    System.out.println("1 을 선택하시면, 계속 앞으로 나아갑니다. 2 를 선택하시면, 휴식을 취합니다.");
                    break;
                }
            }
        }
    }
}

