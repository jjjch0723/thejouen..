package game_separate;

import java.util.HashMap;
import java.util.List;

public class Make_User {
	public void make_user(Player_Status ps) {
		Make_name m_name = new Make_name();
		Select_job s_Job = new Select_job();
		Select_weapon s_Weapon = new Select_weapon();
		Stat_dice s_Dice = new Stat_dice(); 
		
		boolean character_set = true; // 플레이어 생성 진행 여뷰
		int character_set_flag;
		
		playerDAO pd = new playerDAO();
		
		//while 문안에 charcter_set넣기
		while(character_set) {
			m_name.p_name_make(ps); // 해결 완료!
			s_Job.select_job(ps); // 해결 완료!
			s_Weapon.select_weapon(ps); // 해결 완료!
			character_set_flag = s_Dice.stat_dice(ps); // 1 or 2반환
			pd.insertPlayer(ps);
			//List<HashMap<String, Object>> userS = pd.PlayerStatus(ps);
			switch (character_set_flag) {
			case 1:
				character_set = false;
				break;

			case 2:
				character_set = true;
				System.out.println("---------------------------------------------");
				break;
			}
			
		}// charcter_set while문 끝
		int result = pd.insertPlayer(ps);
		System.out.println("캐릭터 생성이 끝났습니다.");
		System.out.println("환영합니다." + ps.getP_name() +"님!");
	}
}
