package game_separate;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class playerDAO {
	public List<HashMap<String, Object>> playerInfo(Player_Status ps){
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT * FROM PLAYER_STATUS ";
		
		List<HashMap<String, Object>> p_list = new ArrayList<>();
		
		try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				HashMap<String, Object> playerMap = new HashMap<String, Object>();
				
				playerMap.put("p_name", rs.getString("p_name"));
				playerMap.put("p_job", rs.getString("p_job"));
				playerMap.put("p_weapon", rs.getString("p_weapon"));
				playerMap.put("p_hp", rs.getString("p_hp"));
				
				p_list.add(playerMap);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e);
		}
		
		return p_list;
	}
	

//	public int insertPlayer(Player_Status ps) {
//		Connection con = null;
//		PreparedStatement psmt = null;
//		ResultSet rs = null;
//
//		String P_hp = Integer.toString(ps.getP_hp());
//		String P_str = Integer.toString(ps.getP_str());
//		String P_dex = Integer.toString(ps.getP_dex());
//		
//		String sql = "INSERT INTO PLAYER_STATUS(seq, p_name, p_level, p_job, p_weapon, p_hp, p_mp, p_str, p_dex, p_int, p_death) "
//				+ "	values(3, "
//				+ "		?, " // name
//				+ "		\"999\", " // level
//				+ "		?, " // job
//				+ "		?, " // weapon
//				+ "		?, " // hp
//				+ "		\"500\", " // mp
//				+ "		?, " // str
//				+ "		?, " // dex
//				+ "		\"30\", " // int
//				+ "		\"N\")"; // death
//		int result = 0;
//		try {
//				con = ConnectionProvider.getConnection();
//				psmt = con.prepareStatement(sql);
//			
//					psmt.setString(1, ps.getP_name());
//					psmt.setString(2, ps.getP_job());
//					psmt.setString(3, ps.getP_weapon_name());
//					psmt.setString(4, P_hp);
//					psmt.setString(5, P_str);
//					psmt.setString(6, P_dex);
//				result = psmt.executeUpdate();
//				
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//			System.out.println(e);
//		}
//		return result;
//	}
	
	public int insertPlayer(Player_Status ps) {
		 Connection con = null;
		 PreparedStatement psmt = null;
		 String sql = "INSERT INTO PLAYER_STATUS(seq, p_name, p_level, p_job, p_weapon, p_hp, p_mp, p_str, p_dex, p_int, p_death) "
					+ "	values(3, "
					+ "		?, " // name
					+ "		\"999\", " // level
					+ "		?, " // job
					+ "		?, " // weapon
					+ "		?, " // hp
					+ "		\"500\", " // mp
					+ "		?, " // str
					+ "		?, " // dex
					+ "		\"30\", " // int
					+ "		\"N\")"; // death
			int result = 0;
			try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);
			
			HashMap<String, Object> uMap = HashUser.insertPlayer(ps);
		
				psmt.setString(1, (String) uMap.get("p_name"));
				psmt.setString(2, (String) uMap.get("p_job"));
				psmt.setString(3, (String) uMap.get("p_weapon"));
				psmt.setString(4, (String) uMap.get("p_hp"));
				psmt.setString(5, (String) uMap.get("p_str"));
				psmt.setString(6, (String) uMap.get("p_dex"));
			result = psmt.executeUpdate();
			
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
		System.out.println(e);
	}
	return result;
		
	}
}
