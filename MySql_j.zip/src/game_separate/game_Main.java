package game_separate;

import java.util.HashMap;

import HashMap_game.MonsterDao;

public class game_Main {

	public static void main(String[] args) {
		// 메인		
	}

}
