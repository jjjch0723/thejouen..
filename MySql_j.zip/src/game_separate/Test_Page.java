package game_separate;

import java.util.HashMap;

import HashMap_game.Insert_Monster;
import HashMap_game.MonsterDao;
import HashMap_game.PlayerDao;
import HashMap_game.Search_Player;
import HashMap_game.Tour;

public class Test_Page {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Player_Status ps = new Player_Status();
//		Monster_Status ms = new Monster_Status(); 
//		
//		Make_User make_User = new Make_User();
		Tour Tour = new Tour();
//		make_User.make_user(ps);
//		Tour.Touring(ps, ms);
//		
		PlayerDao pd = new PlayerDao();
		MonsterDao md = new MonsterDao();
//		Make_name m_name = new Make_name();
//		m_name.p_name_make(ps);
//	
//		
//		String p_name = ps.getP_name();
//		System.out.println(p_name);
//		
//		Search_Player sp = new Search_Player();  //유저 검색
//		sp.search_player(pd);
	}
}


