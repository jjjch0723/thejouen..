package game_separate;

import java.util.Random;
import java.util.Scanner;

public class Tour {
	public void Touring(Player_Status ps, Monster_Status ms) {
		
		boolean tour =  true;
		int tour_flag = 0;
		Random rdm = new Random();
		Scanner sm = new Scanner(System.in);
		Scanner sc = new Scanner(System.in);
		int dice_encounter = 8; // 몬스터 조우 확률 주사위
		int battle = 0;
		int dice_kind = 4;
		
		System.out.printf(
				ps.getP_name() + " 님은 모험의 여행을 떠났습니다. \n" + "1 을 선택하시면, 계속 앞으로 나아갑니다." + " 2 를 선택하시면, 휴식을 취합니다.");
		
		while(tour) {
			Monster_Data m = new Monster_Data();
			Battle_Monster bm = new Battle_Monster();
			Hp_Recovery Recovery = new Hp_Recovery();
			
			int monster_encounter = 0; // 몬스터와 조우
			int monster_kind = ms.getMonster_kind(); // 몬스터의 종
			
			tour_flag = sm.nextInt();

			switch (tour_flag) {
				case 1:
					System.out.println("----------------------------------------------------------");
					System.out.println(ps.getP_name() + " 님 기척이 느껴집니다. (주사위를 굴립니다.)");
					monster_encounter = rdm.nextInt(dice_encounter); // 주사위를 굴려 몬스터 조우 확률을 정함
					System.out.println(monster_encounter + "  나왔습니다.");
						if (monster_encounter > 4) {
							System.out.println("-----------------------------------------------------");
							System.out.println("아무 것도 없습니다. 계속 여행을 떠납니다.");
							System.out.println("1 을 선택하시면, 계속 앞으로 나아갑니다. 2 를 선택하시면, 휴식을 취합니다.");
						} else if (monster_encounter <= 4) {
							System.out.println("-----------------------------------------------------");
							System.out.println("몬스터가 있는 것 같습니다");
							System.out.println("전투를 하시겠습니까 \n(1. Yes   2. No)");
							System.out.println("----------------------------------------------------------");
							battle = sc.nextInt(); // 입력 대기
							
							if(battle == 1) {
								monster_kind = rdm.nextInt(dice_kind); // 주사위를 굴려 몬스터 종류를 정함
								m.monster_set(ps, ms, monster_kind);
								// System.out.println("몬스터의 종류 -> " + monster_kind);
								// System.out.println("몬스터의 이름은 - > " + ms.getMonster_name());
								bm.Battle(ps, ms, monster_kind);
							}else {
								System.out.println("----------------------------------------------------------");
								System.out.println("무사히 도망쳤습니다.");
								System.out.println("----------------------------------------------------------");
								System.out.println("1 을 선택하시면, 계속 앞으로 나아갑니다. 2 를 선택하시면, 휴식을 취합니다.");
								
							}
						}
					break;
				
					case 2:
						System.out.printf("--------------------------------------------- \n"
							+ "잠을 잡니다.  zzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
							Recovery.P_Hp_Recovery(ps);
							// 체력회복 기능 넣기
					break;
				}
		} //tour while문 끝
	}
}

