package game_separate;

import java.util.Scanner;

//직업선택 매세드
public class Select_job {
		
	public void select_job(Player_Status ps) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println(ps.getP_name() + " 님 직업을 선택해주세요.");
		System.out.println("1. 전사		2. 마법사		3. 사냥꾼");
		String job_num = sc.next();
		if(job_num.equals("1")) {
			ps.setP_job("전사");			
		}else if(job_num.equals("2")) {
			ps.setP_job("마법사");		
		}else if(job_num.equals("3")) {
			ps.setP_job("사냥꾼");		
		}
		System.out.println("---------------------------------------------");
		
	}
	
}
