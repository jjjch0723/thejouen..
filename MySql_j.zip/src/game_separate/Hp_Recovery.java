package game_separate;

import java.util.*;

public class Hp_Recovery {
	public void P_Hp_Recovery(Player_Status ps) {
        Random r = new Random();
        int Origin_Player_Hp = ps.getP_hp();
        int Player_Hp;

        // 회복량을 3에서 8 사이의 값으로 설정
        int Recovery_amount = r.nextInt(6) + 3;

        System.out.println("회복을 하기 위한 주사위를 굴립니다");

        System.out.println("주사위의 값이 " + Recovery_amount + " 나왔습니다");
        System.out.println(Recovery_amount + " 만큼 회복합니다.");

        Origin_Player_Hp += Recovery_amount;
        Player_Hp = Origin_Player_Hp;
        ps.setP_hp(Player_Hp);
        System.out.printf(
				ps.getP_name() + " 님의 체펵이 "+ ps.getP_hp() + "가 되었습니다 \n 1 을 선택하시면, 계속 앞으로 나아갑니다.  2 를 선택하시면, 휴식을 취합니다.");
    }
}
