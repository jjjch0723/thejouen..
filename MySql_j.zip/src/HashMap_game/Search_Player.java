package HashMap_game;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Search_Player {
	public boolean search_player(PlayerDao pd, Player_Status ps) {
		
		System.out.println("|-----------------------------------------------------|");
		System.out.println("|          시작 하시려는 캐릭터의 이름을 검색해주세요            |");
		System.out.println("|-----------------------------------------------------|");
		Scanner sc = new Scanner(System.in);
		String Player_name = sc.next();
		boolean game_start = true;
		
		List<HashMap<String, Object>> plist = pd.playerList(Player_name);
		
		for(HashMap<String, Object> PlayerInfo : plist) {
			String p_name = PlayerInfo.get("p_name").toString();
			String p_job = PlayerInfo.get("p_job").toString();
			String p_hp = PlayerInfo.get("p_hp").toString();
			String p_str = PlayerInfo.get("p_str").toString();
			String p_dex = PlayerInfo.get("p_dex").toString();
			String p_int = PlayerInfo.get("p_int").toString();
			ps.setP_name(p_name);
			ps.setP_job(p_job);
			ps.setP_hp(Integer.parseInt(p_hp));
			ps.setP_str(Integer.parseInt(p_str));
			ps.setP_dex(Integer.parseInt(p_dex));
			ps.setP_int(Integer.parseInt(p_int));
			}
		
		System.out.println("검색하신 캐릭터의 정보입니다.");
		System.out.println("| 캐릭터명 : " + ps.getP_name() + "| 직업 : " + ps.getP_job() +"| 체력 : " 
				+ ps.getP_hp() +"| 힘 : " + ps.getP_str() + "| 민첩 : " + ps.getP_dex() + "| 지능 : " + ps.getP_int());
		System.out.println("검색하신 캐릭터의 정보입니다. \n시작 하시겠습니까? \n 1.Y 2.N");
		if(sc.next().equals("1")) {	
			game_start = true;
		}else if(sc.next().equals("2")){
			game_start = false;
		}
		return game_start;
	}
}
