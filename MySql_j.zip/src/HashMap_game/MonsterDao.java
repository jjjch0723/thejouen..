package HashMap_game;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ConnectionProvider;

public class MonsterDao {
	
	public void insertMonster(HashMap<String, Object> mMap) {
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = "INSERT INTO MONSTER_DATA (m_name, m_hp, m_weapon_name, m_weapon_dice, m_str, m_dex, m_int, m_level)\r\n"
				+ "	values(?, ?, ?, ?, ?, ?, ?, ?)";
		
		try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);
			
			HashMap<String, Object> m_Map  = mMap;
				psmt.setString(1, (String) m_Map.get("m_name"));
				psmt.setString(2, (String) m_Map.get("m_hp"));
				psmt.setString(3, (String) m_Map.get("m_weapon_name"));
				psmt.setString(4, (String) m_Map.get("m_weapon_dice"));
				psmt.setString(5, (String) m_Map.get("m_str"));
				psmt.setString(6, (String) m_Map.get("m_dex"));
				psmt.setString(7, (String) m_Map.get("m_int"));
				psmt.setString(8, (String) m_Map.get("m_level"));
			psmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
			
	public List<HashMap<String, Object>> searchMforid(int m_id){
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT m_name, m_hp, m_weapon_name, m_weapon_dice, m_str, m_dex, m_int "
				+  "	from MONSTER_DATA where m_id = ? ";
		
		List<HashMap<String, Object>> monster_List = new ArrayList<>();
		
		try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);
			
			psmt.setInt(1, m_id);
			rs = psmt.executeQuery();
			
			while(rs.next()) {
				HashMap<String, Object> mm = new HashMap<>();
					mm.put("m_name", rs.getString("m_name"));
					mm.put("m_hp", rs.getString("m_hp"));
					mm.put("m_weapon_name", rs.getString("m_weapon_name"));
					mm.put("m_weapon_dice", rs.getString("m_weapon_dice"));
					mm.put("m_str", rs.getString("m_str"));
					mm.put("m_dex", rs.getString("m_dex"));
					mm.put("m_int", rs.getString("m_int"));
				monster_List.add(mm);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}		
		return monster_List;
	}
	
	public int monsterKind() { // 몬스터 종류
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		int monster_count = 0;
		
		String sql = "SELECT COUNT(m_id) AS count "
				+ "	from MONSTER_DATA";
		try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);
			rs = psmt.executeQuery();
			if(rs.next()) {
				monster_count = rs.getInt("count");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return monster_count;
	}
}
