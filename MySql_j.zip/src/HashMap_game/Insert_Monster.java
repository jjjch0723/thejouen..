package HashMap_game;

import java.util.HashMap;
import java.util.Scanner;

public class Insert_Monster {

	public void insert_monster(HashMap<String, Object> mMap) {
		MonsterDao md = new MonsterDao();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("몬스터 생성기");
		System.out.println("몬스터 이름 입력");
		mMap.put("m_name", sc.next());
		System.out.println("몬스터 체력 입력");
		mMap.put("m_hp", sc.next());
		System.out.println("몬스터 무기 입력");
		mMap.put("m_weapon_name", sc.next());
		System.out.println("몬스터 무기 주사위값 입력");
		mMap.put("m_weapon_dice", sc.next());
		System.out.println("몬스터 str 입력");
		mMap.put("m_str", sc.next());
		System.out.println("몬스터 dex 입력");
		mMap.put("m_dex", sc.next());
		System.out.println("몬스터 int 입력");
		mMap.put("m_int", sc.next());
		System.out.println("몬스터 level 입력");
		mMap.put("m_level", sc.next());
		
		md.insertMonster(mMap);
		
	}
}
