package HashMap_game;

public class MonsterVO {

	int m_id;
	String m_name;
	int m_hp;
	String m_weapon_name;
	int m_weapon_dice;
	int m_str;
	int m_dex;
	int m_int;
	int m_level;
	
	public MonsterVO() {
	}

	public MonsterVO(int m_id, String m_name, int m_hp, String m_weapon_name, int m_weapon_dice, int m_str,
			int m_dex, int m_int, int m_level) {
		this.m_id = m_id;
		this.m_name = m_name;
		this.m_hp = m_hp;
		this.m_weapon_name = m_weapon_name;
		this.m_weapon_dice = m_weapon_dice;
		this.m_str = m_str;
		this.m_dex = m_dex;
		this.m_int = m_int;
		this.m_level = m_level;
	}

	public int getM_id() {
		return m_id;
	}

	public void setM_id(int m_id) {
		this.m_id = m_id;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public int getM_hp() {
		return m_hp;
	}

	public void setM_hp(int m_hp) {
		this.m_hp = m_hp;
	}

	public String getM_weapon_name() {
		return m_weapon_name;
	}

	public void setM_weapon_name(String m_weapon_name) {
		this.m_weapon_name = m_weapon_name;
	}

	public int getM_weapon_dice() {
		return m_weapon_dice;
	}

	public void setM_weapon_dice(int m_weapon_dice) {
		this.m_weapon_dice = m_weapon_dice;
	}

	public int getM_str() {
		return m_str;
	}

	public void setM_str(int m_str) {
		this.m_str = m_str;
	}

	public int getM_dex() {
		return m_dex;
	}

	public void setM_dex(int m_dex) {
		this.m_dex = m_dex;
	}

	public int getM_int() {
		return m_int;
	}

	public void setM_int(int m_int) {
		this.m_int = m_int;
	}

	public int getM_level() {
		return m_level;
	}

	public void setM_level(int m_level) {
		this.m_level = m_level;
	}
	
	
}
