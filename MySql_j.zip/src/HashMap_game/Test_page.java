package HashMap_game;

import java.util.HashMap;
import java.util.Random;

public class Test_page {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tour tour = new Tour();

		PlayerDao pd = new PlayerDao();
		MonsterDao md = new MonsterDao();
		Player_Status ps = new Player_Status();
		MonsterVO mv = new MonsterVO();
		Monster_Service ms = new Monster_Service();
		tour.Touring(md, ps, ms, mv);
		
//		ms.Monster_service(md, mv);
//		System.out.println(mv.getM_name());
		
//		HashMap<String, Object> mMap = new HashMap<>();	
//		Insert_Monster im = new Insert_Monster();
//		
//		im.insert_monster(mMap); //몬스터 삽입 	
		


	}

}
