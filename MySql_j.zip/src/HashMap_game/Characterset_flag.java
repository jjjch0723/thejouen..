package HashMap_game;

import java.util.Scanner;

public class Characterset_flag {
	
	public int Character_set_flag(Player_Status ps){
		Scanner sc = new Scanner(System.in);
		System.out.println(ps.getP_name() + " 님 이대로 진행하시겠습니까? (1. YES   2. NO)");
		System.out.println("-------------------------------------------------------");

		int character_set_flag = sc.nextInt();
		return character_set_flag;
	}
}
