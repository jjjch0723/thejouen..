package HashMap_game;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ConnectionProvider;

public class PlayerDao {
	public void insertPlayer(HashMap<String, Object> uMap){
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = "INSERT INTO PLAYER_STATUS(p_name, p_level, p_job, p_weapon,p_hp,p_mp, p_str, p_dex,p_int,p_death, p_weapondice)\r\n"
				+ "	values(? , \"999\" , ? , ? , ? , \"500\" , ? , ? , ? , \"N\" , ? )";
		
		try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);

			HashMap<String, Object> u_Map = uMap;				
				psmt.setString(1, (String) u_Map.get("p_name"));
				psmt.setString(2, (String) u_Map.get("p_job"));
				psmt.setString(3, (String) u_Map.get("p_weapon"));
				psmt.setString(4, (String) u_Map.get("p_hp"));
				psmt.setString(5, (String) u_Map.get("p_str"));
				psmt.setString(6, (String) u_Map.get("p_dex"));
				psmt.setString(7, (String) u_Map.get("p_int"));
				psmt.setString(8, (String) u_Map.get("p_weapondice"));
			psmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<HashMap<String, Object>> playerList(String Player_name) {
		Connection con = null;
		PreparedStatement psmt = null;
		ResultSet rs = null;
		
		String sql = "SELECT p_name, p_job, p_weapon, p_hp, p_str, p_dex, p_int, p_weapondice "
				   + "	from PLAYER_STATUS where p_name = ? ";
		
		List<HashMap<String, Object>> player_List = new ArrayList<>();
		
		try {
			con = ConnectionProvider.getConnection();
			psmt = con.prepareStatement(sql);
			
			psmt.setString(1, Player_name);
			
			rs = psmt.executeQuery();
					
			while(rs.next()) {
				HashMap<String, Object> pm = new HashMap<>();
					pm.put("p_name", rs.getString("p_name"));
					pm.put("p_job", rs.getString("p_job"));
					pm.put("p_weapon", rs.getString("p_weapon"));
					pm.put("p_hp", rs.getString("p_hp"));
					pm.put("p_str", rs.getString("p_str"));
					pm.put("p_dex", rs.getString("p_dex"));
					pm.put("p_int", rs.getString("p_int"));
					pm.put("p_weapondice", rs.getString("p_weapondice"));
				player_List.add(pm);
			}	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return player_List;
	}

}
