package HashMap_game;

import java.util.HashMap;
import java.util.Scanner;

// 무기 선택 메서드
public class Select_weapon {
	
	public void select_weapon(HashMap<String, Object> uMap, Player_Status ps) {
		Scanner sc = new Scanner(System.in);
		Select_job sj = new Select_job();
		int weaponkind = 0;	

		System.out.println("무기를 선택해주세요.");
		System.out.println("---------------------------------------------");
		switch (ps.getP_job()) {
		case "전사": // 전사 선택
			ps.setP_hp(200);
			ps.setP_str(20);
			ps.setP_dex(10);
			ps.setP_int(7);
			uMap.put("p_hp", Integer.toString(ps.getP_hp())); //220
			uMap.put("p_str", Integer.toString( ps.getP_str())); //22
			uMap.put("p_int", Integer.toString(ps.getP_int())); //6
			System.out.println("전사는 다음 무기를 선택할 수 있습니다.");
			System.out.println("1. Sword  2. Bastard Sword");
			weaponkind = sc.nextInt();
			if (weaponkind == 1) {
				ps.setP_weapon_name("Sword");
				uMap.put("p_weapon", ps.getP_weapon_name());

				uMap.put("p_dex", Integer.toString(ps.getP_dex())); //10
				
				ps.setWeapon_dice(4);
				uMap.put("p_weapondice", Integer.toString(ps.getWeapon_dice()));
			} else if (weaponkind == 2) {
				ps.setP_weapon_name("Bastard Sword");
				uMap.put("p_weapon", ps.getP_weapon_name());
				
				int change_dex = ps.getP_dex();
				uMap.put("p_dex", Integer.toString(change_dex - 2)); //10
				
				ps.setWeapon_dice(5);
				uMap.put("p_weapondice", Integer.toString(ps.getWeapon_dice()));
				// ps.p_dex = ps.p_dex - 2; // 무게로 인한 민첩성 저하
			}
			break;

		case "마법사": // 마법사 선택
			ps.setP_hp(100);
			ps.setP_str(8);;
			ps.setP_dex(9);
			ps.setP_int(20);
			uMap.put("p_hp", Integer.toString(ps.getP_hp())); //90
			uMap.put("p_str", Integer.toString(ps.getP_str())); //8
			uMap.put("p_int", Integer.toString(ps.getP_int()));//20
			System.out.println("마법사는 다음 무기를 선택할 수 있습니다.");
			System.out.println("1. Staff    2. Magic Mace");
			weaponkind = sc.nextInt();
			if (weaponkind == 1) {
				ps.setP_weapon_name("Staff");
				uMap.put("p_weapon", ps.getP_weapon_name());;

				ps.setWeapon_dice(5);
				uMap.put("p_weapondice", Integer.toString(ps.getWeapon_dice()));
			} else if (weaponkind == 2) {
				ps.setP_weapon_name("Magic Mace");
				uMap.put("p_weapon", ps.getP_weapon_name());
				
				int change_dex = ps.getP_dex();
				uMap.put("p_dex", Integer.toString(change_dex - 1));

				ps.setWeapon_dice(4);
				uMap.put("p_weapondice", Integer.toString(ps.getWeapon_dice()));
			}
			break;

		case "사냥꾼": // 사냥꾼 선택
			ps.setP_hp(150);
			ps.setP_str(14);
			ps.setP_dex(20);
			ps.setP_int(10);
			uMap.put("p_hp", Integer.toString(ps.getP_hp()));//130
			uMap.put("p_str", Integer.toString(ps.getP_str()));//12
			uMap.put("p_int", Integer.toString(ps.getP_int()));//10
			System.out.println("사냥꾼은 다음 무기를 선택할 수 있습니다.");
			System.out.println("1. Long Bow    2. Bolt");
			weaponkind = sc.nextInt();
			if (weaponkind == 1) {
				ps.setP_weapon_name("Long Bow");
				uMap.put("p_weapon", ps.getP_weapon_name());

				ps.setWeapon_dice(7);
				uMap.put("p_weapondice", Integer.toString(ps.getWeapon_dice()));
			} else if (weaponkind == 2) {
				uMap.put("p_weapon", ps.getP_weapon_name());
				                                                                                                  
				int change_dex = ps.getP_dex();
				uMap.put("p_dex", Integer.toString(change_dex - 2)); //10

				ps.setWeapon_dice(5);
				uMap.put("p_weapondice", Integer.toString(ps.getWeapon_dice()));
			}
			break;
		}

		
		System.out.println("-------------------------------------------------------");
		System.out.printf("* " + ps.getP_weapon_name() + " * 을/를 선택하셨습니다. 공격 시 " + ps.getWeapon_dice() + " 면체 주사위를 굴립니다. \n ");
		System.out.println("-------------------------------------------------------");
	}

}
