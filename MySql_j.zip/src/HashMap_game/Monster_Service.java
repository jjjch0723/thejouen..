package HashMap_game;

import java.util.HashMap;
import java.util.List;
import java.util.Random;


public class Monster_Service {

	public void Monster_service(MonsterDao md, MonsterVO mv) {
		Random rd = new Random();
		int m_kind = md.monsterKind();
		int m_id = rd.nextInt(m_kind); // 몬스터 종류
		
		List<HashMap<String, Object>> mlist = md.searchMforid(m_id+1);
		for(HashMap<String, Object> monster_kind : mlist) {
			String m_name = monster_kind.get("m_name").toString();
			String m_hp = monster_kind.get("m_hp").toString();
			String m_weapon_name = monster_kind.get("m_weapon_name").toString();
			String m_wepon_dice = monster_kind.get("m_weapon_dice").toString();
			String m_str = monster_kind.get("m_str").toString();
			String m_dex = monster_kind.get("m_dex").toString();
			String m_int = monster_kind.get("m_int").toString();
			mv.setM_name(m_name);
			mv.setM_hp(Integer.parseInt(m_hp));
			mv.setM_weapon_name(m_weapon_name);
			mv.setM_weapon_dice(Integer.parseInt(m_wepon_dice));
			mv.setM_str(Integer.parseInt(m_str));
			mv.setM_dex(Integer.parseInt(m_dex));
			mv.setM_int(Integer.parseInt(m_int));
		}
	}
}
