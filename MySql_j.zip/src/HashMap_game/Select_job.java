package HashMap_game;

import java.util.HashMap;
import java.util.Scanner;

//직업선택 매세드
public class Select_job {
		
	public void select_job(HashMap<String, Object> uMap, Player_Status ps) {
		Scanner sc = new Scanner(System.in);
		String job = "";
		
		System.out.println(ps.getP_name() + "님 직업을 선택해주세요.");
		System.out.println("1. 전사		2. 마법사		3. 사냥꾼");
		String job_num = sc.next();
		if(job_num.equals("1")) {
			//job = "전사";
			ps.setP_job(job = "전사");
		}else if(job_num.equals("2")) {
			//job = "마법사";	
			ps.setP_job(job = "마법사");
		}else if(job_num.equals("3")) {
			//job = "사냥꾼";	
			ps.setP_job(job = "사냥꾼");
		}
		uMap.put("p_job", job);
		//pd.insertPlayer(uMap);
		System.out.println("---------------------------------------------");
		
	}
	
}
