package HashMap_game;

import java.util.HashMap;

public class h_gameMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Make_User mk = new Make_User();
		HashMap<String, Object> uMap = new HashMap<>();
		Player_Status ps = new Player_Status();
		
		mk.make_user(uMap, ps);
		
	}

}
