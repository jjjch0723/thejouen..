package HashMap_game;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class make_name {

	public void p_name_make( HashMap<String, Object> uMap, Player_Status ps){
		Scanner sc = new Scanner(System.in);
		System.out.println("당신의 이름을 입력하세요.");
		
		String p_name = sc.next();
		
		ps.setP_name(p_name);
		uMap.put("p_name", p_name);
		//pd.insertPlayer(uMap);
	}
}
