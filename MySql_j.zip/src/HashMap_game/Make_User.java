package HashMap_game;

import java.util.HashMap;

public class Make_User {
	public void make_user(HashMap<String, Object> uMap ,Player_Status ps) {
		make_name mk = new make_name();
		Select_job sj = new Select_job();
		Select_weapon sw = new Select_weapon();
		Stat_dice sd = new Stat_dice();
		PlayerDao pd = new PlayerDao();
		Characterset_flag cf = new Characterset_flag();
		
		boolean character_set = true; // 플레이어 생성 진행 여뷰
		int character_set_flag;
		
		while(character_set) {
			mk.p_name_make(uMap, ps);
			sj.select_job(uMap, ps);
			sw.select_weapon(uMap, ps);	
			sd.stat_dice(uMap, ps);
			
			character_set_flag = cf.Character_set_flag(ps);
			switch (character_set_flag) {
			case 1:
				pd.insertPlayer(uMap);
				character_set = false;
				break;

			case 2:
				character_set = true;
				System.out.println("---------------------------------------------");
				break;
			}
			
		}// charcter_set while문 끝
		
		
		System.out.println("캐릭터 생성이 끝났습니다.");
		System.out.println("환영합니다." + ps.getP_name() +"님!");		
	}		
}

