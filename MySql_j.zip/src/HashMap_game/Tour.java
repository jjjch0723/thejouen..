package HashMap_game;

import java.util.HashMap;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Tour {

	public void Touring(MonsterDao md, Player_Status ps, Monster_Service ms, MonsterVO mv) {
		
		PlayerDao pd = new PlayerDao();
		Scanner sc = new Scanner(System.in);
		Search_Player sp = new Search_Player();
		Random rd = new Random();
		Battle bl = new Battle();
		boolean game_start = sp.search_player(pd, ps);
		int monster_encounter = 0;
		int dice_encounter = 8;
		boolean tour = true;
		int tour_flag = 0;
		int battle = 0;
		while(game_start) {
			System.out.printf(
				ps.getP_name() + " 님은 모험의 여행을 떠났습니다. \n" + "1 을 선택하시면, 계속 앞으로 나아갑니다." + " 2 를 선택하시면, 휴식을 취합니다.");
			
			while(tour) {					
				tour_flag = sc.nextInt();
					switch (tour_flag) {
					case 1:
						System.out.println("----------------------------------------------------------");
						System.out.println(ps.getP_name() + " 님 기척이 느껴집니다. (주사위를 굴립니다.)");
						monster_encounter = rd.nextInt(dice_encounter); // 주사위를 굴려 몬스터 조우 확률을 정함
						System.out.println(monster_encounter + "  나왔습니다.");
							if (monster_encounter > 4) {
								System.out.println("-----------------------------------------------------");
								System.out.println("아무 것도 없습니다. 계속 여행을 떠납니다.");
								System.out.println("1 을 선택하시면, 계속 앞으로 나아갑니다. 2 를 선택하시면, 휴식을 취합니다.");
							} else if (monster_encounter <= 4) {
								ms.Monster_service(md, mv);
								System.out.println("-----------------------------------------------------");
								System.out.println("몬스터가 있는 것 같습니다");
								System.out.println("전투를 하시겠습니까 \n(1. Yes   2. No)");
								System.out.println("----------------------------------------------------------");
								//System.out.println(mv.getM_name() + "이(가) 등장했습니다");
								battle = sc.nextInt(); // 입력 대기
								
								if(battle == 1) {
									//battle 메서드 구현
									bl.Battle(ps, mv);
								}else {
									System.out.println("----------------------------------------------------------");
									System.out.println("무사히 도망쳤습니다.");
									System.out.println("----------------------------------------------------------");
									System.out.println("1 을 선택하시면, 계속 앞으로 나아갑니다. 2 를 선택하시면, 휴식을 취합니다.");
								}
							}
						break;
					
						case 2:
							System.out.printf("--------------------------------------------- \n"
								+ "잠을 잡니다.  zzzzzzzzzzzzzzzzzzzzzzzzzzzzz");
	
								// 체력회복 기능 넣기
						break;
					}
				}

		}
	}
}
