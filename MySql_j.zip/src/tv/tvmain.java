package tv;

import java.util.Scanner;

public class tvmain {

    public static void main(String[] args) {
        boolean tvOn = true;
        int channel = 11;
        int volume = 10;

        Scanner sc = new Scanner(System.in);

        while (tvOn) {
            remote();
            
            String command = sc.next();
            
            if (command.equals("채널업")) {
                channel = channelUp(channel);
            } else if (command.equals("채널다운")) {
                channel = channelDown(channel);
            } else if (command.equals("볼륨업")) {
                volume = volUp(volume);
            } else if (command.equals("볼륨다운")) {
                volume = volDown(volume);
            } else if (command.equals("이동")) {// command의 값이 이동이면 새 메서드 만들기
            	System.out.println("이동하시려는 채널을 입력해주세요");
            	channel = cMove(channel);
            } else if(command.equals("종료")) { 
            	tvOn = false;
            	System.out.println("TV를 종료합니다.");
            }
            now(channel, volume);
        }
    }

    public static int channelUp(int channel) {
        return channel + 1;
    } // 채널업

    public static int channelDown(int channel) {
        return channel - 1;
    } // 채널다운

    public static int volUp(int volume) {
        return volume + 1;
    } // 볼륨업

    public static int volDown(int volume) {
        return volume - 1;
    } // 볼륨다운
    
    public static int cMove(int channel) {
    	Scanner sc = new Scanner(System.in);
    	int c_move = sc.nextInt();
    	channel = c_move;
    	return channel;
    } // 채널이동

    public static void remote() {
        System.out.println("채널을 이동하시려면 '채널업' 혹은 '채널다운', "
                + "볼륨 조정은 '볼륨업' 혹은 '볼륨다운', "
                + "특정 채널로 이동하시려면 해당 채널 번호를 입력,"
                + "특정 채널로 이동하시려면 '이동' 종료하려면 '종료'를 입력하세요.");
    } 
 
    public static void now(int channel, int volume) {
        System.out.println("현재 채널은 " + channel + "이고, 볼륨은 " + volume + "입니다.");
    }
}
