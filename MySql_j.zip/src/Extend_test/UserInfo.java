package Extend_test;

public class UserInfo extends LoginInfo{
	
	String userNm;
	int userAge;
	String userEmail;
	
	public UserInfo(String userNm, int userAge, String userEmail) {
		super();
		this.userNm = userNm;
		this.userAge = userAge;
		this.userEmail = userEmail;
	}

	public UserInfo() {
	}
	
	
}
