package Extend_test;

public class UserCheck {

	public boolean userCheck(UserInfo ui) {
		if(ui.userId.equals("전준") && ui.userPw.equals("1111") && ui.oper.equals("!")) {
			return true;				
			
		}else {
			return false;			
		}
	}

}
