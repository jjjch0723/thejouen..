package Extend_test;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Id입력");
		String userId = sc.next();
		System.out.println("Pw입력");
		String userPw = sc.next();
		System.out.println("Oper입력");
		String oper = sc.next();
		
		
		UserInfo ui = new UserInfo();
		ui.userId = userId;
		ui.userPw = userPw;
		ui.oper = oper;
		
		UserCheck uc = new UserCheck();
		
		boolean check = uc.userCheck(ui);
		
		if(check) {
			System.out.println("로그인성공");
		}else {
			System.out.println("로그인실패");
		}
	}

}
