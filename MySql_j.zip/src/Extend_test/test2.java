package Extend_test;

import java.util.Scanner;

public class test2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		test3 t3 = new test3();
		int cal = 0;
		
		System.out.println("수 입력");
		int num1 = sc.nextInt(); 
		t3.setNum1(num1);
		
		System.out.println("계산식 입력");
		String oper = sc.next();
		t3.setOper(oper);
		
		System.out.println("수 입력");
		int num2 = sc.nextInt();
		t3.setNum2(num2);
		
		if(t3.getOper().equals("+")) {
			cal = t3.getNum1() + t3.getNum2();
		}else if(t3.getOper().equals("-")) {
			cal = t3.getNum1() - t3.getNum2();
		}else if(t3.getOper().equals("x")) {
			cal = t3.getNum1() * t3.getNum2();
		}
		System.out.println("결과 값은 " + t3.getNum1() + t3.getOper() + t3.getNum2() + "=" + cal + "입니다");
	}

}
