package Extend_test;

public class test3 {
	private int num1;
	private int num2;
	private String oper;

	public test3() {
		super();
	}
	public test3(int num1, int num2, String oper) {
		super();
		this.num1 = num1;
		this.num2 = num2;
		this.oper = oper;
	}
	public int getNum1() {
		return num1;
	}
	public void setNum1(int num1) {
		this.num1 = num1;
	}
	public int getNum2() {
		return num2;
	}
	public void setNum2(int num2) {
		this.num2 = num2;
	}
	public String getOper() {
		return oper;
	}
	public void setOper(String oper) {
		this.oper = oper;
	}
	
}
