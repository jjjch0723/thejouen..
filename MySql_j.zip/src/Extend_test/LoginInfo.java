package Extend_test;

public class LoginInfo {

	String userId;
	String userPw;
	String oper;
	
	public LoginInfo() {}

	public LoginInfo(String userId, String userPw, String oper) {
		this.userId = userId;
		this.userPw = userPw;
		this.oper = oper;
	}
}
