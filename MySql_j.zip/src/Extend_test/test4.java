package Extend_test;

public class test4 {

}
