package com;

import java.util.Date;

public class ContentVo {
	int Brdno;
	String Brdtitle;
	String Brdmemo;
	Date Brddate;
	
	public ContentVo() {
	}

	public ContentVo(int brdno, String brdtitle, String brdmemo, Date brddate) {
		super();
		Brdno = brdno;
		Brdtitle = brdtitle;
		Brdmemo = brdmemo;
		Brddate = brddate;
	}

	public Date getBrddate() {
		return Brddate;
	}

	public void setBrddate(Date brddate) {
		Brddate = brddate;
	}

	public int getBrdno() {
		return Brdno;
	}

	public void setBrdno(int brdno) {
		Brdno = brdno;
	}

	public String getBrdtitle() {
		return Brdtitle;
	}

	public void setBrdtitle(String brdtitle) {
		Brdtitle = brdtitle;
	}

	public String getBrdmemo() {
		return Brdmemo;
	}

	public void setBrdmemo(String brdmemo) {
		Brdmemo = brdmemo;
	}
	
}
