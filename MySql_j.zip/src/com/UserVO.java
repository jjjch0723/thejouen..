package com;

public class UserVO {
	private int userNo;
	private String userId;
	private String userNm;
	
	public UserVO() {
	}

	public UserVO(int userNo, String userId, String userNm) {
		this.userNo = userNo;
		this.userId = userId;
		this.userNm = userNm;
	}
	
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	
	
}
