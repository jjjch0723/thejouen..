package com;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		journalDAO jd = new journalDAO();
		
		List<journalVO> jlist = jd.journalInfo();
		
		for(journalVO jl : jlist) {
			int id = jl.getId();
			String journal_nm = jl.getJournal_nm();
			String issn = jl.getIssn();
			String eiisn = jl.getEissn();
			String factor = jl.getFactor();
			
			System.out.println("id : " + id + " journal_nm : " + journal_nm + " issn : " + issn + " eissn : "
					+ eiisn + " factor : " + factor);
		}

	}

}
