package com;

public class journalVO {
	int id;
	String journal_nm;
	String issn;
	String eissn;
	String factor;
	public journalVO() {}
	public journalVO(int id, String journal_nm, String issn, String eissn, String factor) {
		this.id = id;
		this.journal_nm = journal_nm;
		this.issn = issn;
		this.eissn = eissn;
		this.factor = factor;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getJournal_nm() {
		return journal_nm;
	}
	public void setJournal_nm(String journal_nm) {
		this.journal_nm = journal_nm;
	}
	public String getIssn() {
		return issn;
	}
	public void setIssn(String issn) {
		this.issn = issn;
	}
	public String getEissn() {
		return eissn;
	}
	public void setEissn(String eissn) {
		this.eissn = eissn;
	}
	public String getFactor() {
		return factor;
	}
	public void setFactor(String factor) {
		this.factor = factor;
	}
	
	
}
