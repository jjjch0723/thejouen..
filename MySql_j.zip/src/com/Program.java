package com;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;


public class Program {

	public static void main(String[] args) {
//		UserDAO ud = new UserDAO();
//		
//		List<UserVO> list = new ArrayList<UserVO>();
//		
//		list = ud.userInfo();
//		
//		for(UserVO uv : list) {
//			int userNo = uv.getUserNo();
//			String userId = uv.getUserId();
//			String userNm = uv.getUserNm();
//			
//			System.out.println("|-----------------------------------------------------|");
//			System.out.println("| 사용자 번호 | "+ userNo + " | 사용자 ID | " + userId + " | 사용자 이름 | " + userNm +" |");
//			System.out.println("|-----------------------------------------------------|");
		
		System.out.println("|-----------------------------------------------------|");
		System.out.println("| 검색 하시려는 책의 이름을 검색해주세요 모르실 경우 n을 눌러주세요");
		System.out.println("|-----------------------------------------------------|");
		Scanner sc = new Scanner(System.in);
		String keyword = sc.next();
		System.out.println("|-----------------------------------------------------|");
		System.out.println("| 검색 하시려는 책의 저자명을 검색해주세요 모르실 경우 n을 눌러주세요");
		System.out.println("|-----------------------------------------------------|");
		Scanner sc1 = new Scanner(System.in);
		String userword = sc1.next();
		System.out.println("|-----------------------------------------------------|");
		//SerachDAO sd = new SerachDAO();
		
		//List<searchVO> slist = sd.searchInfo(keyword, userword);
		
		SearchDAO2 sd2 = new SearchDAO2();
		
		List<HashMap<String, Object>> slist = sd2.searchInfo2(keyword, userword);
		
//		for(searchVO sv : slist) {
//			String UserNm = sv.getUserNm();
//			int Brdno = sv.getBrdno();
//			String Brdtitle = sv.getBrdtitle();
//			String Brdmemo = sv.getBrdmemo();	
//			
//			if(UserNm.equals("")) {
//				System.out.println("tq");
//			}else {				
//				System.out.println("책 번호 : "+Brdno +" | 책 이름 : " + Brdtitle + " | 책 메모 : " + Brdmemo + " | 책의 저자 : " + UserNm);				
//			}
//			
//		}	해쉬 맵을 사용하지 않는 경우
		for(HashMap<String, Object> sv2 : slist) {
			String Usernm = sv2.get("USERNM").toString();
			int Brdno = (int) sv2.get("BRDNO");
			String Brdtitle = sv2.get("BRDTITLE").toString();
			String Brdmemo = sv2.get("BRDMEMO").toString();
			
			System.out.println("| 책 번호 : "+Brdno +" | 책 이름 : " + Brdtitle + " | 책 메모 : " 
					+ Brdmemo + " | 책의 저자 : " + Usernm + " |");				
		}
	}
}

