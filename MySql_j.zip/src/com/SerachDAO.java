package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SerachDAO {
    public List<searchVO> searchInfo(String keyword, String userword) {
        Connection con = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
//  	UserVO ur = new UserVO();  //빈통 하나 생성

        String sql = " SELECT tb.BRDNO, tb.BRDTITLE , tb.BRDMEMO, cu.USERNM "
                + "         FROM TBL_BOARD tb, "
                + "                  COM_USER cu "
                + "       WHERE tb.BRDTITLE LIKE ? "
                + "            AND cu.USERNM LIKE ? "
                + "            AND cu.USERNO = tb.USERNO ";

        List<searchVO> slist = new ArrayList<searchVO>();

        try {
                con = ConnectionProvider.getConnection();
                psmt = con.prepareStatement(sql);
                if(keyword.equals("n")) {
                	psmt.setString(1, "%%");
                    psmt.setString(2, "%" + userword + "%");
                }else if(userword.equals("n")){
                	psmt.setString(1, "%" + keyword + "%");
                	psmt.setString(2, "%%");                	
                }
                rs = psmt.executeQuery();

                while(rs.next()) { //DB의 데이터가 더는 없다면
//                    ur.setUserNo(rs.getInt("USERNO"));
//                    ur.setUserId(rs.getString("USERID"));
//                    ur.setUserNm(rs.getString("USERNM"));

                    String userNm = rs.getString("USERNM");
                    int Brdno = rs.getInt("BRDNO");
                    String Brdtitle = rs.getString("BRDTITLE");
                    String Brdmemo = rs.getString("BRDMEMO");
                    	
                   searchVO sv = new searchVO(userNm, Brdno, Brdtitle, Brdmemo);
                    
                    slist.add(sv); // 그리고 uv객체를 list에 넣어라
                }

        } catch (Exception e) {
                e.printStackTrace();
        }
        return slist; //uv가 담긴 list 반환
    }
    
//    public List<ContentVO> contentInfo(String keyword) {
//        Connection con = null;
//        PreparedStatement psmt = null;
//        ResultSet rs = null;
//    //    UserVO ur = new UserVO();  //빈통 하나 생성
//
//        String sql = " SELECT BRDNO, BRDTITLE, BRDMEMO "
//        		+ "	FROM TBL_BOARD tb "
//        		+ "	WHERE BRDTITLE LIKE ? ";
//
//        List<ContentVO>list = new ArrayList<UserVO>();
//
//        try {
//                con = ConnectionProvider.getConnection();
//                psmt = con.prepareStatement(sql);
//                psmt.setString(1, sql);
//                rs = psmt.executeQuery();
//
//                while(rs.next()) { //DB의 데이터가 더는 없다면
////                    ur.setUserNo(rs.getInt("USERNO"));
////                    ur.setUserId(rs.getString("USERID"));
////                    ur.setUserNm(rs.getString("USERNM"));
//
//                    int userNo = rs.getInt("USERNO");
//                    String userId = rs.getString("USERID");
//                    String userNm = rs.getString("USERNM");
//                    
//                    UserVO uv = new UserVO(userNo, userId, userNm); //uv객체에 번호, 아이디, 이름을 넣어라
//                    
//                    list.add(uv); // 그리고 uv객체를 list에 넣어라
//                }
//
//        } catch (Exception e) {
//                e.printStackTrace();
//        }
//        return list; //uv가 담긴 list 반환
//    }
}
