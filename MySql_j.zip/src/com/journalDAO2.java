package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class journalDAO2 {
	public List<HashMap<String, Object>> journalInfo2(){
		Connection con = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        
        String sql = "SELECT * "
        		+ "	FROM journal_impact_temp WHERE id < 10 ";
        
        List<HashMap<String, Object>> jlist2 = new ArrayList<>();
        
        try {
        	con = ConnectionProvider.getConnection();
            psmt = con.prepareStatement(sql);
            rs = psmt.executeQuery(sql);
            
            while(rs.next()) {
            	
            	HashMap<String, Object> journalMap = new HashMap<>();
            	
            	journalMap.put("id", rs.getInt("id"));
            	journalMap.put("journal_nm", rs.getString("journal_nm"));
            	journalMap.put("issn", rs.getString("issn"));
            	journalMap.put("eissn", rs.getString("eissn"));
            	journalMap.put("factor", rs.getString("factor"));
            	
            	jlist2.add(journalMap);
            }
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
        return jlist2;
	}
}
