package com;

import java.util.HashMap;
import java.util.List;

public class journalTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		journalDAO2 jd2 = new journalDAO2();
		
		List<HashMap<String, Object>> jlist2 = jd2.journalInfo2();
		
		for(HashMap<String, Object> jv2 : jlist2) {
			int id = (int) jv2.get("id");
			String journal_nm = jv2.get("journal_nm").toString();
			String issn = jv2.get("issn").toString();
			String eissn = jv2.get("issn").toString();
//			float factor = (Float) jv2.get("factor");
			String factor = jv2.get("factor").toString();
			float factor_ = Float.parseFloat(factor);
			
		
			float factorfloat = Math.round(factor_ / 30);
			factor_ = factorfloat;
			
			System.out.println("id : " + id + " journal_nm : " + journal_nm + " issn : " + issn + " eissn : "
					+ eissn + " factor : " + factor_);
			System.out.println(factor_);
		}
	}

}
