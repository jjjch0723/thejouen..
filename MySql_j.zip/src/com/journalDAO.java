package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class journalDAO {
	public List<journalVO> journalInfo(){
		 	Connection con = null;
	        PreparedStatement psmt = null;
	        ResultSet rs = null;
	        
	        String sql = "SELECT * "
	        		+ "	FROM journal_impact_temp WHERE id < 10 ";
	        
	        List<journalVO> jlist = new ArrayList<journalVO>();
	        
	        try {
	        	con = ConnectionProvider.getConnection();
	            psmt = con.prepareStatement(sql);
	            rs = psmt.executeQuery(sql);
	            
	            while(rs.next()) {
	            	int id = rs.getInt("id");
	            	String journal_nm = rs.getString("journal_nm");
	            	String issn = rs.getString("issn");
	            	String eissn = rs.getString("eissn");
	            	String factor = rs.getString("factor");
	            	float factorfloat = Float.parseFloat(factor); // 형 변환
	            	
	            	if (eissn.isBlank()) {
	            		eissn = rs.getString("issn");
	            		//issn = rs.getString("eissn");
	            	}
	            	for(int i = 0; i <= jlist.size(); i++) {
	            		
	            		float factorfloat_ = Math.round(factorfloat / 30);
	            		factor = Float.toString(factorfloat_);
	            	}
	            	
	            	journalVO gv = new journalVO(id, journal_nm, issn, eissn, factor);
	            	
	            	jlist.add(gv);
	            }
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	        
	        return jlist;
	}
}
