package com;

public class test_4 {

	public static void main(String[] args) {
		int[] answer = { 1,4,4,3,1,4,4,2,1,3,2 }; 
		int[] counter = new int[4];
		
		for(int i=0; i < answer.length;i++) { 
			if(answer[i] == 1) {
				System.out.println("*");					
			}else if(answer[i] == 2) {
				System.out.println("**");
			}else if(answer[i] == 3) {
				System.out.println("***");
			}else if(answer[i] == 4) {
				System.out.println("****");
			}
		}
	}
}




