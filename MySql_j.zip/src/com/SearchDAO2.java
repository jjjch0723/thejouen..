package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SearchDAO2 {

	public List<HashMap<String, Object>> searchInfo2(String keyword, String userword){
		Connection con = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
        
        String sql = " SELECT tb.BRDNO, tb.BRDTITLE , tb.BRDMEMO, cu.USERNM "
                + "         FROM TBL_BOARD tb, "
                + "                  COM_USER cu "
                + "       WHERE tb.BRDTITLE LIKE ? "
                + "            AND cu.USERNM LIKE ? "
                + "            AND cu.USERNO = tb.USERNO ";
        
       List<HashMap<String, Object>> list = new ArrayList<>();
       
       try {
           con = ConnectionProvider.getConnection();
           psmt = con.prepareStatement(sql);
           
           if(keyword.equals("n")) {
           		psmt.setString(1, "%%");
           		psmt.setString(2, "%" + userword + "%");
           }else if(userword.equals("n")){
           		psmt.setString(1, "%" + keyword + "%");
           		psmt.setString(2, "%%");   
           }else {
        	   	psmt.setString(1, "%" + keyword + "%");
          		psmt.setString(2, "%" + userword + "%");
           }
           rs = psmt.executeQuery();

           	while(rs.next()) {
           		HashMap<String, Object> searchMap = new HashMap<>();
           		searchMap.put("USERNM", rs.getString("USERNM"));
           		searchMap.put("BRDNO", rs.getInt("BRDNO"));
           		searchMap.put("BRDTITLE", rs.getString("BRDTITLE"));
           		searchMap.put("BRDMEMO", rs.getString("BRDMEMO"));
           		list.add(searchMap);
           		
             	} // while 끝
           	
        } // try 끝 
       catch (Exception e) {
           e.printStackTrace();
        }
       return list;
	}
}

