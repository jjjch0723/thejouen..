package com;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ContentDAO {
	public List<ContentVo> contentInfo(String keyword) {
        Connection con = null;
        PreparedStatement psmt = null;
        ResultSet rs = null;
    //    UserVO ur = new UserVO();  //빈통 하나 생성
        

        String sql = " SELECT tb.BRDNO, tb.BRDTITLE , tb.BRDMEMO, cu.USERNM "
                + "         FROM TBL_BOARD tb, "
                + "                  COM_USER cu "
                + "       WHERE tb.BRDTITLE LIKE ? "
                + "            AND cu.USERNM LIKE ? "
                + "            AND cu.USERNO = tb.USERNO ";

        List<ContentVo> list = new ArrayList<ContentVo>();
        
        try {
        	 con = ConnectionProvider.getConnection();
             psmt = con.prepareStatement(sql);
             psmt.setString(1, "%" + keyword + "%");
             psmt.setString(2, "%%");
             rs = psmt.executeQuery();
             
                while(rs.next()) { //DB의 데이터가 더 없어질때까지
//                    ur.setUserNo(rs.getInt("USERNO"));
//                    ur.setUserId(rs.getString("USERID"));
//                    ur.setUserNm(rs.getString("USERNM"));

                    int Brdno = rs.getInt("BRDNO");
                    String Brdtitle = rs.getString("BRDTITLE");
                    String Brdmemo = rs.getString("BRDMEMO");
                    Date Brddate = rs.getDate("BRDDATE");
                    
                    ContentVo cv = new ContentVo(Brdno, Brdtitle, Brdmemo, Brddate);//uv객체에 번호, 아이디, 이름을 넣어라
                    
                    list.add(cv); // 그리고 uv객체를 list에 넣어라
                }

        } catch (Exception e) {
                e.printStackTrace();
        }
        return list; //uv가 담긴 list 반환
    }
	
}
