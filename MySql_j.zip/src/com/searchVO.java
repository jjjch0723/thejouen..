package com;

import java.util.Date;

public class searchVO {
	String userNm;
	int Brdno;
	String Brdtitle;
	String Brdmemo;
	
	public searchVO() {
		super();
	}
	
	public searchVO(String userId, int brdno, String brdtitle, String brdmemo) {
		super();
		this.userNm = userId;
		Brdno = brdno;
		Brdtitle = brdtitle;
		Brdmemo = brdmemo;
	}
	public String getUserNm() {
		return userNm;
	}
	public void setUserNm(String userId) {
		this.userNm = userId;
	}
	public int getBrdno() {
		return Brdno;
	}
	public void setBrdno(int brdno) {
		Brdno = brdno;
	}
	public String getBrdtitle() {
		return Brdtitle;
	}
	public void setBrdtitle(String brdtitle) {
		Brdtitle = brdtitle;
	}
	public String getBrdmemo() {
		return Brdmemo;
	}
	public void setBrdmemo(String brdmemo) {
		Brdmemo = brdmemo;
	}
	
	
	
}
