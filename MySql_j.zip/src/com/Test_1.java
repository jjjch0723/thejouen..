package com;

import java.util.Scanner;

public class Test_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1. c, d
		
		//2 . (numOfApples / sizeOfBucket) + 1 몫을 구한뒤 나머지가 담길 바구니인 +1을 함
		
		/*3.int i = 0;
    		while (i <= 10) {
	        int j = 0; // i, j 를 내부에서 초기화
	        while (j <= i) {
	            System.out.print("*");
	            j++;
		        }
	        System.out.println();
	        i++;
    		}
		 * */ 
		
		/*4.
		 *  for (int i = num; i > 0; i /= 10) { // num을 10으로 나누고
            sum += i % 10; // 나머지를 계속 더함
        	}
		 * */
		
		/*5. for(int i : arr) {
			sum += i; // for each로 배열 하나씩 들고와서 sum에 더하기
			}*/
		/*
		 * 6. if(answer[i] == 1) { 첫번째 for문에 넣으면 나옵니다 ㅎㅎ;
				System.out.println("*");					
			}else if(answer[i] == 2) {
				System.out.println("**");
			}else if(answer[i] == 3) {
				System.out.println("***");
			}else if(answer[i] == 4) {
				System.out.println("****");
			}*/
		boolean order_run = true;
		welcom();
		String chose_order = cupsize();
		tastechose(chose_order);

		}
	
	public static void welcom() {
		System.out.println("************************");
		System.out.println("*베스킨라빈스 31 입니다.*");
		System.out.println("************************");
	}
	
	public static String cupsize() {
		Scanner sc = new Scanner(System.in);
		
		String cup_size[] = { "하프갤런", "패밀리", "쿼터", "파인트" };
		
		System.out.println("사이즈를 선택해주세요. .");
		System.out.println("*********************");
		for (int i = 0; i < cup_size.length; i++) {
			System.out.println((i + 1) + "." + cup_size[i]);
		}
		System.out.println("*********************");
		String chose_order1 = sc.nextLine();
		return chose_order1;
	}
	
	public static void tastechose(String chose_order) {
		String icecream_taste[] = { "베리베리스트로베리", "아몬드봉봉", "슈팅스타", "아빠는딸바붕", "엄마는 외계인", "민트초코", "그린티" };
		String chose_taste[] = new String[6]; // 선택한 맛이 입력될 배열
		Scanner sc = new Scanner(System.in);
		
		int order_price = 0; // 계산 결과
		int product_price[] = { 30000, 20000, 15000, 9800 }; // 사이즈별 금액
		
		boolean taste_seq = true;
		int taste_cnt = 0;
		while (taste_seq) {
			System.out.println("*********************");
			for (int i = 0; i < chose_taste.length; i++) {
				System.out.println((i + 1) + "." + icecream_taste[i]);
			}
			System.out.println("*********************");

			System.out.println((taste_cnt + 1) + " 번째 맛을 선택하세요.");
			chose_taste[taste_cnt] = sc.nextLine();
			
			String message = icecream_taste[Integer.parseInt(chose_taste[taste_cnt]) - 1];
			System.out.println(message + " 이(가) 선택되었습니다.");

			System.out.println("컵크기 : " + chose_order);
			System.out.println("taste_cnt : " + taste_cnt);
			taste_cnt++;
			if (chose_order.equals("4") && taste_cnt == 3) {
				taste_seq = false;
				order_price = product_price[3];
			} else if (chose_order.equals("3") && taste_cnt == 4) {
				taste_seq = false;
				order_price = product_price[2];
			} else if (chose_order.equals("2") && taste_cnt == 5) {
				taste_seq = false;
				order_price = product_price[1];
			} else if (chose_order.equals("1") && taste_cnt == 6) {
				taste_seq = false;
				order_price = product_price[0];
			}
			System.out.println("주문이 완료되었습니다.");
			System.out.println("*********************");
			System.out.println("선택하신 맛은");
			for (int i = 0; i < chose_taste.length; i++) {
				if(chose_taste[i]!=null) {
					int idx = Integer.parseInt(chose_taste[i]);
					String order_message = icecream_taste[idx-1];
					System.out.println(order_message);
				}

			}
			System.out.println("*********************");

			System.out.println(" 주문하신 제품의 금액은 :" + order_price + " 원 입니다.");	
		}
	}
}
