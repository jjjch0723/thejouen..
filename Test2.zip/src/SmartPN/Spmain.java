package SmartPN;

import java.util.Scanner;

//1. 전원 
//2. 인터넷
//3. 유튜브
//4. 연락처 배열로 받아서 찾기까지 (가변배열로 해보기? 안된다 십발;)
//5. 볼륨 조절

public class Spmain {
    static Scanner sc = new Scanner(System.in);
    static boolean smOn = true;
    static int volume = 10;
    static String[] phoneNums = new String[10]; 
    static int pnIndex = 0; 

    public static void main(String[] args) {
        while (smOn) {
            remote();
            String command = sc.next();
            
            if (command.equals("c_on")) {
                Interneton();
            } else if (command.equals("c_off")) {
                Internetoff();
            } else if (command.equals("y_on")) {
                Youtubeon();
            } else if (command.equals("y_off")) {
                Youtubeoff();
            } else if (command.equals("+")) {
                volume = volUp(volume);
            } else if (command.equals("-")) {
                volume = volDown(volume);
            } else if (command.equals("연락처")) {
                System.out.println("검색할 연락처를 입력하세요 : ");
                String searchContact = sc.next();
                serachPnums(searchContact);
            } else if (command.equals("추가")) {
                addContact();
            } else if (command.equals("종료")) {
                smOn = false;
                System.out.println("휴대폰을 종료합니다.");
            }
        }
        sc.close();
    }

    public static void Interneton() {
        System.out.println("인터넷이 켜졌습니다");
    }

    public static void Internetoff() {
        System.out.println("인터넷이 꺼졌습니다");
    }

    public static void Youtubeon() {
        System.out.println("유튜브가 켜졌습니다");
    }

    public static void Youtubeoff() {
        System.out.println("유튜브가 꺼졌습니다");
    }

    public static int volUp(int volume) {
        return volume + 1;
    }

    public static int volDown(int volume) {
        return volume - 1;
    }

    public static void addContact() { 
    	if (pnIndex < phoneNums.length) {
    		System.out.println("추가할 연락처를 입력:");
    		String newPn = sc.next();
    		phoneNums[pnIndex++] = newPn;
    		System.out.println("연락처 추가.");
    	} else {
    		System.out.println("연락처가 가득 찼습니다.");
    	}
    } // 연착처 추가 
    // 연락처 가변배열로 해보기?
    
    // 자고 일어나서 연락처 찾기 만들어놔라
    public static void serachPnums(String searchN) {
        boolean found = false;
        for (String pn : phoneNums) {
            if (pn != null && pn.equals(searchN)) {
                System.out.println(searchN + "의 전화번호가 존재합니다. : " + pn);
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println(searchN + "의 전화번호가 존재하지 않습니다.");
        }
    } // 연락처 찾기

    public static void remote() {
        System.out.println("유튜브는 'y_on, y_off' 인터넷은 'c_on, c_off', \n"
                + "볼륨 조정은 '+' 혹은 '-', \n"
                + "연락처는 '연락처', \n,"
                + "연락처 추가는 '추가', \n"
                + "휴대폰 종료는 '종료'를 입력해주세세요.");
    }

}