package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Program {

	public static void main(String[] args) {
		CoffemenuVO cv = new CoffemenuVO();
		Main_screen m = new Main_screen();
		m.main_screen(cv);

	}

}
