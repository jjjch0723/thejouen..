package main;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Manager {
	Scanner sc = new Scanner(System.in);
	
	public void Managing(CoffemenuVO cv) {
		List<HashMap<String, Object>> coffeelist = cv.getMlist();
		System.out.println("비밀번호를 입력 해주세요.");
		String pwd = sc.next();
		int cnt = 0;
		ManagerService ms = new ManagerService();
		boolean managing = true;
		
		while(managing) {
			if(pwd.equals("1111")) {
				ms.m_Screen(cv);
				managing = true;
				break;
			}else {
				System.out.println("5회 잘못입력시 종료됩니다 \n"
						+ "잘못된입력입니다. " + cnt + "회째 트라이중~");
				cnt++;
				if(cnt == 5) {
					managing = false;				
				}
			}
		}
		
	}
}
