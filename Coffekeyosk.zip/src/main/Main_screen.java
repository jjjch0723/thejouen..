package main;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Main_screen {
	Scanner sc = new Scanner(System.in);
	
	public void main_screen(CoffemenuVO cv) {
		boolean flag = true;
		Manager mg = new Manager();
		Customer cm = new Customer();
		List<HashMap<String, Object>> coffeelist = cv.getMlist();
		
		while(flag) {
			System.out.println("|------환영합니다 ------|");
			System.out.println("|------1. 구매 -------|");
			System.out.println("|-----2. 관리자 -------|");
			System.out.println("|-----3. 이전화면 -----|");
			String choice = sc.next();
			
			if(choice.equals("1")) {
				// 구매 탭
				cm.Customer_m(cv);
			}else if (choice.equals("2")) {
				// 관리자 탭
				mg.Managing(cv);
			}else if (choice.equals("3")) {
				Start_keyosk s = new Start_keyosk();
				s.start();
			}else {
				System.out.println("잘못된 입력입니다.");
				flag = true;
			}			
		}
		
	}
}
