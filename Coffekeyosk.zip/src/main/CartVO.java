package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CartVO {
	private List<HashMap<String, Object>> cartlist = new ArrayList<>();

	public CartVO() {
		super();
	}

	public CartVO(List<HashMap<String, Object>> cartlist) {
		super();
		this.cartlist = cartlist;
	}

	public List<HashMap<String, Object>> getCartlist() {
		return cartlist;
	}

	public void setCartlist(List<HashMap<String, Object>> cartlist) {
		this.cartlist = cartlist;
	}
	
	
}
