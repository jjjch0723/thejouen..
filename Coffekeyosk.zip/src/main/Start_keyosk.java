package main;

import java.util.Scanner;

public class Start_keyosk {
	Scanner sc = new Scanner(System.in);
	public void start() {
		System.out.println("기계를 켜시겠습니까?");
		String startflag = sc.next();
		if(startflag.equals("y")) {
			
		}else {
			System.out.println("기계를 종료합니다.");
		}
	}
}
