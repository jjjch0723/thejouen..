package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class HashManager {
	
}
