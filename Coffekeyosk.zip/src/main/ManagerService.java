package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class ManagerService {
    public List<HashMap<String, Object>> m_Screen(CoffemenuVO cv) {
        Scanner sc = new Scanner(System.in);
        List<HashMap<String, Object>> clist = cv.getMlist(); // cv 객체를 직접 참조합니다.
        boolean cFlag = true;
        boolean exit = true;
        
        while (exit) {
            System.out.println("상품 등록은 1 \n 이전화면으로 돌아가시려면 2");
            String exit_c = sc.next();
            
            if (exit_c.equals("1")) {    
                while (cFlag) {
                    System.out.println("새 상품 입력");
                    String newCof = sc.next();
                    System.out.println("가격 입력");
                    int ncPrice = sc.nextInt();
                    
                    System.out.println("새 상품의 이름은 : " + newCof);
                    System.out.println("새 상품의 가격은 : " + ncPrice);
                    System.out.println("추가하시려면 1 \n다시 하시려면 아뮤키나 눌러주세요");
                    String c = sc.next();
                    
                    HashMap<String, Object> cm = new HashMap<>();
                    cm.put("newCoffe", newCof);
                    cm.put("ncPrice", ncPrice);
                    
                    if (c.equals("1")) {
                        clist.add(cm);
                        System.out.println("추가 되었습니다.");
                        System.out.println("더 추가하시겠습니까? (1: Yes, 0: No)");
                        int choice = sc.nextInt();
                        if (choice != 1) {
                            cFlag = false;
                        }
                    } else {
                        System.out.println("다시 입력해주세요");
                    }
                    break;
                }
                cFlag = true;
            } else if (exit_c.equals("2")) {
                exit = false;
                break;
            }
        }
        return clist;
    }
}
