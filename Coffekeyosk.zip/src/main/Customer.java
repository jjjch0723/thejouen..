package main;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

public class Customer {

    public List<HashMap<String,Object>> Customer_m(CoffemenuVO cv, CartVO uv) {
    	Scanner sc = new Scanner(System.in);
        List<HashMap<String, Object>> coffeelist = cv.getMlist();
        List<HashMap<String, Object>> cartlist = uv.getCartlist();
        HashMap<String, Object> uMap = new HashMap<>();
        int coffeecnt = 1;
        for (HashMap<String, Object> ch : coffeelist) {
        	String cofs = (String) ch.get("newCoffe");
            int cPrices = (Integer) ch.get("ncPrice");
            System.out.printf(coffeecnt + "| %s | %d원 |\n", cofs, cPrices);
            coffeecnt += 1;
            
            uMap.put("cofs", cofs);
            uMap.put("cPrice", cPrices);
        }
        cartlist.add(uMap);
        return cartlist;
    }
}
