package main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class CoffemenuVO {
    private int cnt;
    private List<HashMap<String, Object>> mlist = new ArrayList<>(); // 빈 리스트로 초기화합니다.

    public CoffemenuVO() {
    }

    public CoffemenuVO(int cnt, List<HashMap<String, Object>> mlist) {
        this.cnt = cnt;
        this.mlist = mlist;
    }

    public int getCnt() {
        return cnt;
    }

    public void setCnt(int cnt) {
        this.cnt = cnt;
    }

    public List<HashMap<String, Object>> getMlist() {
        return mlist;
    }

    public void setMlist(List<HashMap<String, Object>> mlist) {
        this.mlist = mlist;
    }
}
