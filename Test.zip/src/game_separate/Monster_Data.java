package game_separate;

public class Monster_Data {

	public void monster_set(Player_Status ps ,Monster_Status ms, int Monster_kind){
				
	    switch (Monster_kind) {
	    case 0:
	    	ms.setMonster_kind(1);
	        ms.setMonster_name("Kobold");
	        ms.setMonster_HP(100);
	        ms.setM_weapon_name("Dangger");
	        ms.setM_weapon_dice(4);
	        ms.setMonster_str(10);
	        ms.setMonster_dex(8);
	        ms.setMonster_level(1);
	        break;
	
	    case 1:
	    	ms.setMonster_kind(2);
	        ms.setMonster_name("Ork");
	        ms.setMonster_HP(150);
	        ms.setM_weapon_name("Stick");
	        ms.setM_weapon_dice(6);
	        ms.setMonster_str(14);
	        ms.setMonster_dex(7);
	        ms.setMonster_level(2);
	        break;
	
	    case 2:
	    	ms.setMonster_kind(3);
	        ms.setMonster_name("Ork Leader");
	        ms.setMonster_HP(200);
	        ms.setM_weapon_name("Mace");
	        ms.setM_weapon_dice(8);
	        ms.setMonster_str(15);
	        ms.setMonster_dex(9);
	        ms.setMonster_level(3);
	        break;
	
	    case 3:
	    	ms.setMonster_kind(4);
	        ms.setMonster_name("Orge");
	        ms.setMonster_HP(300);
	        ms.setM_weapon_name("Stick");
	        ms.setM_weapon_dice(6);
	        ms.setMonster_str(18);
	        ms.setMonster_dex(10);
	        ms.setMonster_level(4);
	        break;
	
	    case 4:
	    	ms.setMonster_kind(5);
	        ms.setMonster_name("Fallen knight");
	        ms.setMonster_HP(200);
	        ms.setM_weapon_name("Bastard Sword");
	        ms.setM_weapon_dice(8);
	        ms.setMonster_str(18);
	        ms.setMonster_dex(12);
	        ms.setMonster_level(5);
	        break;
	    }
	    
	    System.out.println(ps.getP_name() + "님! "+ ms.getMonster_name() + "이(가) 출현했습니다!");
	}
}
