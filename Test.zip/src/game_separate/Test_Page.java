package game_separate;

public class Test_Page {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player_Status ps = new Player_Status();
		Monster_Status ms = new Monster_Status(); 
		
		Make_User make_User = new Make_User();
		Tour Tour = new Tour();
		
		make_User.make_user(ps);
		Tour.Touring(ps, ms);
		
	}
}

