package game_separate;

public class game_Main {

	public static void main(String[] args) {
		// 메인
		
		
	}

}
